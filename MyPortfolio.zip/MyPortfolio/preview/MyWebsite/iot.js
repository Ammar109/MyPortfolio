window.onload = demo;
function demo() {
    document.getElementById("gsc-i-id1").setAttribute("placeholder", "Search IOT Related Articles ")
}
$(document).ready(function(){
		$('.next').on('click',function(){
			var currentImg=$('.active');
			var nextImg=currentImg.next();
			if (nextImg.length) {
				currentImg.removeClass('active').css('z-index',-10);
				nextImg.addClass('active').css('z-index',10);
			}
		});

		$('.prev').on('click',function(){
			var currentImg=$('.active');
			var nextImg=currentImg.prev();
			if (nextImg.length) {
				currentImg.removeClass('active').css('z-index',-10);
				nextImg.addClass('active').css('z-index',10);
			}
		});
		 
	});

		 	var myMenu = document.getElementById('menuitem');
		 	myMenu.style.maxHeight='0px';
		 	function menufunc() {

		 		if (myMenu.style.maxHeight=='0px') {
		 			myMenu.style.maxHeight='250px';
		 		}
		 		else{
		 			myMenu.style.maxHeight='0px';
		 		}
		 	}
	const btn = document.querySelector(".night1");
	const currentTheme=localStorage.getItem("theme");
	if (currentTheme=="dark") {
		document.body.classList.add("dark-theme");
		document.getElementById("night1").style.borderColor = "gold";
	}
	btn.addEventListener("click",function(){
		document.body.classList.toggle("dark-theme");
		let theme="light";
		if (document.body.classList.contains("dark-theme")) {
			theme="dark"
		}
		localStorage.setItem("theme",theme);
		
	});

const todoForm = document.querySelector('.todo-form');
const todoInput = document.querySelector('.todo-input');
const todoItemsList = document.querySelector('.todo-items');
let todos = [];
todoForm.addEventListener('submit', function(event) {
  event.preventDefault();
  addTodo(todoInput.value);
});
function addTodo(item) {
  if (item !== '') {
    const todo = {
      id: Date.now(),
      name: item,
      completed: false
    };
    todos.push(todo);
    addToLocalStorage(todos);
    todoInput.value = '';
  }
}
function renderTodos(todos) {
  todoItemsList.innerHTML = '';
  todos.forEach(function(item) {
    const checked = item.completed ? 'checked': null;
    const li = document.createElement('li');
    li.setAttribute('class', 'item');
    li.setAttribute('data-key', item.id);
    if (item.completed === true) {
      li.classList.add('checked');
    }
    li.innerHTML = `<input type="checkbox" class="checkbox" ${checked}>${item.name}<button class="delete-button">X</button>`;
    todoItemsList.append(li);
  });
}
function addToLocalStorage(todos) {
  localStorage.setItem('todos', JSON.stringify(todos));
  renderTodos(todos);
}
function getFromLocalStorage() {
  const reference = localStorage.getItem('todos');
  if (reference) {
    todos = JSON.parse(reference);
    renderTodos(todos);
  }
}
function toggle(id) {
  todos.forEach(function(item) {
    if (item.id == id) {
      item.completed = !item.completed;
    }
  });

  addToLocalStorage(todos);
}
function deleteTodo(id) {
  todos = todos.filter(function(item) {
    return item.id != id;
  });
  addToLocalStorage(todos);
}
getFromLocalStorage();
todoItemsList.addEventListener('click', function(event) {
  if (event.target.type === 'checkbox') {
    toggle(event.target.parentElement.getAttribute('data-key'));
  }
  if (event.target.classList.contains('delete-button')) {
    deleteTodo(event.target.parentElement.getAttribute('data-key'));
  }
});	 	